public abstract class Figura {


}